# Repeatable quality check

Use Node 24 and install dependencies with `npm ci --ignore-scripts`. Install the pinned Chromium once with `npx playwright install chromium` (Linux CI: `npx playwright install --with-deps chromium`).

`npm run quality` runs TypeScript, every `tests/*.test.ts` test, the production Vite build, and six browser scenarios in sequence. It stops at the first failure and writes durations/status to `test-results/quality-summary.json`. `npm run test:e2e` reruns browser checks against the existing build; rebuild first after changing the UI.

The browser suite starts its own HTTP server on `127.0.0.1:4339` and refuses to reuse an occupied port. It serves `dist/client` and the real published cloud API with 36 clearly labelled TEST records in memory. Only the bootstrap's calendar day is fixed, so default date filters are repeatable. It never reads `.env`, uses the production snapshot, writes a database, or collects upstream data. Browser requests for map tiles receive visibly synthetic OFFLINE QA tiles; unexpected remote requests, API mutations and runtime exceptions fail the check. The server also rejects all outbound `fetch` calls.

Coverage: national bootstrap; pagination and reset; regional search; card/table/map/export result agreement; detail facts; free-price filter; obsolete-request cancellation; search retry; map cancellation/reentry; tile-outage fallback; region keyboard dismissal/focus; 375px mobile cards/region/detail/table/map/empty states, horizontal overflow, 44px touch targets, a delayed map-search loading label, and linked date-validation messages. Spreadsheet contents are checked after an actual browser download.

Artifacts are ignored locally: `test-results/e2e/` contains desktop/mobile screenshots and workbook evidence; failures retain screenshots and traces. `playwright-report/` is the HTML report (`npx playwright show-report`). CI uploads both folders for 14 days. Screenshots show synthetic fixtures and synthetic map backgrounds, not live production data. Chromium smoke does not establish Safari/Firefox, real provider availability, live map rendering or 3D GPU quality.

The `Quality` workflow checks PRs and supports manual runs. Repository branch protection must separately require its `quality` job if merge blocking is desired. Main pushes run the same command in the refresh workflow before deployment, so any validation failure prevents that deployment without duplicating the entire check in two workflows.
