import ExcelJS from 'exceljs';
import { test, expect, openPublished, expectTotal, selectAndong } from './helpers.js';

test('published search, cards, table, map, detail and export share the same regional results', async ({ page }, testInfo) => {
  await openPublished(page);
  await expect(page.locator('.performance-card')).toHaveCount(30);
  await page.getByRole('button', { name: '다음 페이지', exact: true }).click();
  await expect(page.locator('.performance-card')).toHaveCount(6);
  await expect(page.getByRole('navigation', { name: '검색 결과 페이지' })).toContainText('2 / 2 페이지');
  await selectAndong(page); // A new filter also resets page 2 back to page 1.
  const titles = ['TEST 안동 무료 음악', 'TEST 안동 유료 연극'];
  const cardTitles = page.locator('.performance-card h3');
  expect((await cardTitles.allTextContents()).sort()).toEqual(titles);
  await page.screenshot({ path: testInfo.outputPath('desktop-cards.png'), fullPage: true });

  await page.getByRole('button', { name: 'TEST 안동 무료 음악', exact: true }).click();
  const detail = page.getByRole('dialog', { name: 'TEST 안동 무료 음악' });
  await expect(detail.getByText('TEST 출연진', { exact: true })).toBeVisible();
  await expect(detail.getByText('TEST 대공연장', { exact: true })).toBeVisible();
  await expect(detail.getByRole('button', { name: '상세 정보 가져오기', exact: true })).toHaveCount(0);
  await detail.getByRole('button', { name: '닫기', exact: true }).click();

  await page.getByRole('button', { name: '표', exact: true }).click();
  await expect(page.locator('.search-table tbody tr')).toHaveCount(2);
  expect((await page.locator('.search-table tbody th').allTextContents()).sort()).toEqual(titles);
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: '엑셀 내보내기', exact: true }).click();
  const download = await downloadPromise;
  const workbookPath = testInfo.outputPath('regional-results.xlsx');
  await download.saveAs(workbookPath);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(workbookPath);
  const rows = workbook.getWorksheet('공연 목록')!;
  expect(rows.rowCount).toBe(3);
  expect([rows.getCell('B2').text, rows.getCell('B3').text].sort()).toEqual(titles);
  const evidence = workbook.getWorksheet('조회 근거')!;
  expect(evidence.getCell('B3').text).toContain('andong');

  const mapResponse = page.waitForResponse(response => new URL(response.url()).pathname === '/api/map');
  await page.getByRole('button', { name: '지도 + 목록', exact: true }).click();
  const map = await (await mapResponse).json();
  expect(map.total).toBe(2);
  expect(map.items.map((item: { title: string }) => item.title).sort()).toEqual(titles);
  await expect(page.getByText('공연장 위치 1건 · 위치 미확인 1건', { exact: true })).toBeVisible();
  await expect(page.locator('.map-result-list .performance-card')).toHaveCount(2);
  await page.screenshot({ path: testInfo.outputPath('desktop-map.png'), fullPage: true });

  await page.getByRole('button', { name: /^상세 조건/ }).click();
  await page.getByRole('combobox', { name: /^관람료/ }).selectOption('free');
  await expectTotal(page, 1);
  await expect(page.locator('.map-result-list h3')).toHaveText('TEST 안동 무료 음악');
});

test('obsolete searches are aborted and cannot replace the newest result', async ({ page }) => {
  await openPublished(page);
  let release!: () => void;
  const held = new Promise<void>(resolve => { release = resolve; });
  let started!: () => void;
  const intercepted = new Promise<void>(resolve => { started = resolve; });
  const cancelled: string[] = [];
  page.on('requestfailed', request => { if (new URL(request.url()).searchParams.get('q') === '안동') cancelled.push(request.failure()?.errorText ?? ''); });
  await page.route('**/api/performances?**', async route => {
    if (new URL(route.request().url()).searchParams.get('q') !== '안동') return route.fallback();
    const response = await route.fetch();
    started();
    await held;
    await route.fulfill({ response }).catch(() => {}); // The browser intentionally cancels this response.
  });
  try {
    await page.getByRole('searchbox', { name: '공연명·공연장 검색' }).fill('안동');
    await intercepted;
    await page.getByRole('searchbox', { name: '공연명·공연장 검색' }).fill('강릉');
    await expectTotal(page, 1);
    await expect(page.locator('.performance-card h3')).toHaveText('TEST 강릉 유료 음악');
    await expect.poll(() => cancelled.length).toBeGreaterThan(0);
  } finally { release(); }
  await expect(page.getByText('검색 결과를 불러오지 못했습니다', { exact: true })).toHaveCount(0);
  await expect(page.locator('.performance-card h3')).toHaveText('TEST 강릉 유료 음악');
});

test('search failure retries cleanly and restores the requested result', async ({ page }) => {
  await openPublished(page);
  let attempts = 0;
  let release!: () => void;
  const held = new Promise<void>(resolve => { release = resolve; });
  await page.route('**/api/performances?**', async route => {
    if (new URL(route.request().url()).searchParams.get('q') !== '강릉') return route.fallback();
    if (++attempts === 1) return route.fulfill({ status: 503, contentType: 'application/json', body: '{"error":"TEST temporary failure"}' });
    await held;
    return route.fallback();
  });
  await page.getByRole('searchbox', { name: '공연명·공연장 검색' }).fill('강릉');
  await expect(page.getByText('검색 결과를 불러오지 못했습니다', { exact: true })).toBeVisible();
  try {
    await page.getByRole('button', { name: '다시 시도', exact: true }).click();
    await expect(page.getByText('검색 결과를 불러오지 못했습니다', { exact: true })).toHaveCount(0);
    await expect(page.locator('.results')).toHaveAttribute('aria-busy', 'true');
  } finally { release(); }
  await expectTotal(page, 1);
  await expect(page.locator('.performance-card h3')).toHaveText('TEST 강릉 유료 음악');
  expect(attempts).toBe(2);
});

test('map exit cancels its request and reentry works when external tiles fail', async ({ page }) => {
  await openPublished(page);
  let release!: () => void;
  const held = new Promise<void>(resolve => { release = resolve; });
  let started!: () => void;
  const intercepted = new Promise<void>(resolve => { started = resolve; });
  let first = true;
  const cancelled: string[] = [];
  page.on('requestfailed', request => { if (new URL(request.url()).pathname === '/api/map') cancelled.push(request.failure()?.errorText ?? ''); });
  await page.route('https://tile.openstreetmap.org/**', route => route.fulfill({ status: 503, body: 'TEST tile outage' }));
  await page.route('**/api/map?**', async route => {
    if (!first) return route.fallback();
    first = false;
    const response = await route.fetch(); started();
    await held;
    await route.fulfill({ response }).catch(() => {});
  });
  try {
    await page.getByRole('button', { name: '지도 + 목록', exact: true }).click();
    await intercepted;
    await page.getByRole('button', { name: '카드', exact: true }).click();
    await expect(page.locator('.performance-grid .performance-card')).toHaveCount(30);
    await expect.poll(() => cancelled.length).toBeGreaterThan(0);
  } finally { release(); }
  await page.getByRole('button', { name: '지도 + 목록', exact: true }).click();
  await expect(page.locator('.map-scope-note')).toContainText('검색 결과 36건');
  await expect(page.getByText('지도 배경을 불러오지 못했습니다. 공연 마커와 목록은 계속 이용할 수 있습니다.', { exact: true })).toBeVisible();
  await expect(page.locator('.map-result-list .performance-card')).toHaveCount(30);
  await page.getByRole('button', { name: 'TEST 여수 정기 공연 36', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'TEST 여수 정기 공연 36' })).toBeVisible();
});

test('region dialog supports keyboard dismissal and restores focus', async ({ page }) => {
  await openPublished(page);
  const trigger = page.getByRole('button', { name: /^지역 선택/ }).first();
  await trigger.focus();
  await page.keyboard.press('Enter');
  const dialog = page.getByRole('dialog', { name: '전국 지역 선택' });
  await expect(dialog).toBeVisible();
  await expect(page.locator('dialog[open] :focus')).toHaveCount(1);
  await page.keyboard.press('Escape');
  await expect(dialog).not.toBeVisible();
  await expect(trigger).toBeFocused();
  await expectTotal(page, 36);
});
